<x-layout>
    <x-slot:title>{{ $title }}</x-slot>
    <h3>Ini Contact euy</h3>
</x-layout>