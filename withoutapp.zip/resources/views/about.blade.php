<x-layout>
    <x-slot:title>{{ $title }}</x-slot>
    <h3>Ini About euy</h3>
    <p>Nama adalah: {{ $nama }}</p>
</x-layout>