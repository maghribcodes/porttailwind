{{-- {{ dd($title) }} --}}
<x-layout>
    <x-slot:title>{{ $title }}</x-slot>
    <h3>Ini Homepage</h3>
</x-layout>
